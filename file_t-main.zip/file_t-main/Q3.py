# 내가 43250원이 있다 
# 만원 짜리는 몇개 있고
# 오천원 짜리는 몇개 있고
# 천원 짜리는 몇개 있고
# 500 은 몇개있고
# 100 은 몇개있고
# 50원 은 몇개있고
# 10원 은 몇개있다.

# money = 43250
# if money // 10000 >= 1:
#     print(f"만원 짜리는 {money//10000}개 있고")
#     money -= (money//10000) * 10000
# if money // 5000 >= 1:
#     print(f"5000원 짜리는 {money//5000}개 있고")
#     money = money - (money//5000) * 5000
# else:
#     print(f"5000원 짜리는 없고")
# if money // 1000 >= 1:
#     print(f"1000원 짜리는 {money//1000}개 있고")
#     money = money - (money//1000) * 1000
# and or
# and 둘다 맞아야하고
# or 둘 중 하나 또는 다 만족
# 12 
# a = 47
# answer = f"{a}는 "
# if a % 2 == 0 and a % 3 == 0:
#     answer += "2 와 3의 공배수 입니다"
# elif a % 2 == 0 or a % 3 == 0:
#     if a % 2 == 0:
#         answer += "2의 배수 입니다"
#     elif a % 3 == 0:
#         answer += "3의 배수 입니다"
# else: 
#     answer += "2 와 3의 공배수 아닙니다"
# print(answer)

# a = 11
# print(f"{a}는 2 와 3의 공배수 아닙니다")
# a = 10
# print(f"{a}는 2의 배수 입니다")
# a = 9
# print(f"{a}는 3의 배수 입니다")

