# a,b = [2,3,4,5,10],[4,5,6,7,8]
a = [2,3,4,5,10]
b = [4,5,6,7,8]
set_a = set(a)
set_b = set(b)
print(max(set_a  & set_b))



