# 툴 반복문 조건문
# hi 를 출력하는 프로그램
# 주석 코드에서 무시한다
# print("hi")


# 두번째
# 세번째 
# 조건문
# 5 는 짝수 True False
# 5 는 짝수입니다
# 5 는 짝수 아닙니다
num = 7
if num % 3 == 1 : # 첫번째 조건
    print("5 는 짝수입니다")
elif num % 3 != 2: # 두번째 조건  
    print("5 는 짝수 아닙니다")
elif num % 3 == 2: # 세번째 조건
    print("5 는 짝수 아닙니다")
else: # 다 아닐때
    print("else")
    print("다")
print("아님") 






